package com.example.javafx;

public class Usuario {

    public int codigo;
    public  String usuario;
    public String senha;


    }

