package com.example.javafx;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class PerfilController {

    @FXML
    TextField usuarioField;
    @FXML
    TextField senhaField;


    public void inicialize(URL url, ResourceBundle resourceBundle){
    }
    public void editarPerfil() throws IOException{

        Usuario usuario =

    }

    public void voltar() throws IOException {
        HelloApplication.setRoot("main-view");

    }





}
