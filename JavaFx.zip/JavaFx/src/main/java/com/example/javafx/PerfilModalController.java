package com.example.javafx;

public class PerfilModalController {
    public void salvar() {

    }
}
